# Developer AI Track — Project Rules

## Stack
- **Frontend:** Next.js 14 (App Router) · TypeScript · Tailwind CSS · Framer Motion
- **Backend:** FastAPI (Python 3.12+) · Uvicorn · Motor (async MongoDB)
- **AI Layer:** IBM Watsonx AI (`ibm-watsonx-ai` SDK) — Granite model, SSE streaming
- **Database:** MongoDB (Motor async driver)

## Commands
```bash
# Frontend
cd frontend && npm install && npm run dev      # dev server on :3000
npm run build && npm run typecheck             # before committing

# Backend
cd backend && pip install -r requirements.txt
cp .env.example .env                           # fill in secrets
uvicorn app.main:app --reload --port 8000
```

## Aesthetic Rules (Frontend)
- Dark-mode only — background `#0d1117`, surface `#161b22`, border `#30363d`
- Monospace font (`JetBrains Mono`) for all code, labels, and UI text
- Accent: blue `#3b82f6`, purple `#7c3aed` — use sparingly
- Animations via Framer Motion — keep subtle (`duration: 0.2s`, no bounces)
- Components must feel like a premium IDE / terminal tool

## Code Style
- TypeScript strict mode — no `any`, no `!` non-null assertions without comment
- React: functional components only, `"use client"` only when needed
- Python: type hints everywhere, Pydantic v2 models for all I/O
- Separate concerns: `components/` ↔ `lib/` ↔ `types/`
- Keep functions small and pure; side effects in explicit service layers

## AI / Streaming Rules
- All AI calls go through the FastAPI proxy — never call Watsonx directly from the browser
- Use SSE (`text/event-stream`) for streaming; format: `data: <chunk>\n\n`, end with `data: [DONE]\n\n`
- Always show a skeleton / typing indicator while streaming
- Handle API errors with user-friendly inline messages (no raw stack traces in UI)

## Security
- API keys live in `backend/.env` only — never committed, never sent to client
- CORS restricted to `CORS_ORIGINS` env var (default: `http://localhost:3000`)
- MongoDB connection string stays server-side

## File Structure
```
frontend/
  src/
    app/          # Next.js App Router pages
    components/   # Reusable UI components
    lib/          # API client, utilities
    types/        # TypeScript interfaces

backend/
  app/
    routes/       # FastAPI routers (chat, history)
    main.py       # App entry point + CORS
    watsonx.py    # Watsonx AI service layer
    db.py         # MongoDB Motor client
    models.py     # Pydantic schemas
    config.py     # Settings from .env
```
