# Developer AI Track

> Full-stack AI developer tool — Next.js · FastAPI · Watsonx AI · MongoDB

---

## Quick Start

### Prerequisites
- Node.js 20+
- Python 3.12+
- MongoDB (local or Atlas)
- IBM Cloud account with Watsonx project

### 1 · Frontend

```bash
cd frontend
npm install
npm run dev          # http://localhost:3000
```

### 2 · Backend

```bash
cd backend
python -m venv .venv
.venv\Scripts\activate       # Windows
# source .venv/bin/activate  # macOS/Linux

pip install -r requirements.txt
cp .env.example .env
# → fill WATSONX_API_KEY, WATSONX_PROJECT_ID, MONGODB_URI

uvicorn app.main:app --reload --port 8000
# API docs: http://localhost:8000/api/docs
```

---

## Project Structure

```
p1/
├── frontend/              # Next.js 14 App Router
│   ├── src/
│   │   ├── app/           # Pages (/, /chat, /docs)
│   │   ├── components/    # ChatMessage, ChatInput, Sidebar
│   │   ├── lib/           # api.ts  ← Watsonx SSE client
│   │   └── types/         # chat.ts interfaces
│   ├── tailwind.config.js
│   └── package.json
│
├── backend/               # FastAPI Python
│   ├── app/
│   │   ├── routes/        # /api/chat/stream, /api/history
│   │   ├── main.py        # App + CORS
│   │   ├── watsonx.py     # IBM Watsonx streaming proxy
│   │   ├── db.py          # Motor MongoDB client
│   │   ├── models.py      # Pydantic schemas
│   │   └── config.py      # .env settings
│   └── requirements.txt
│
└── AGENTS.md              # Bob project rules
```

---

## API Reference

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/api/chat/stream` | Stream Watsonx response (SSE) |
| `GET`  | `/api/history` | Fetch message history from MongoDB |
| `GET`  | `/api/health` | Health check |

---

## Environment Variables (Backend)

| Variable | Description |
|----------|-------------|
| `MONGODB_URI` | MongoDB connection string |
| `MONGODB_DB` | Database name (default: `ai_track`) |
| `WATSONX_API_KEY` | IBM Cloud API key |
| `WATSONX_PROJECT_ID` | Watsonx project ID |
| `WATSONX_URL` | Watsonx endpoint URL |
| `WATSONX_MODEL_ID` | Model (default: `ibm/granite-13b-chat-v2`) |
| `CORS_ORIGINS` | Allowed origins (comma-separated) |
