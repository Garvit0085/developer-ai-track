from datetime import datetime, timezone
from fastapi import APIRouter
from fastapi.responses import StreamingResponse

from app.models import ChatRequest
from app.watsonx import stream_response
from app.db import get_db

router = APIRouter(prefix="/api/chat", tags=["chat"])


@router.post("/stream")
async def chat_stream(body: ChatRequest):
    """
    Streams the Watsonx AI response as Server-Sent Events.
    Also persists the final assistant reply to MongoDB.
    """
    messages = [m.model_dump() for m in body.messages]

    async def event_generator():
        full_response = ""
        async for chunk in stream_response(messages):
            # Accumulate for persistence
            if chunk.startswith("data: ") and not chunk.strip().endswith("[DONE]"):
                full_response += chunk[6:].rstrip("\n")
            yield chunk

        # Persist exchange to MongoDB
        db = get_db()
        now = datetime.now(timezone.utc)
        docs = [
            *[{**m, "timestamp": now} for m in messages],
            {"role": "assistant", "content": full_response, "timestamp": now},
        ]
        await db.messages.insert_many(docs)

    return StreamingResponse(event_generator(), media_type="text/event-stream")
