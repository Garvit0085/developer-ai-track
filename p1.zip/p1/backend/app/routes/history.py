from fastapi import APIRouter
from app.db import get_db

router = APIRouter(prefix="/api/history", tags=["history"])


@router.get("")
async def get_history(limit: int = 50):
    """Return the last `limit` messages from MongoDB."""
    db = get_db()
    cursor = db.messages.find({}, {"_id": 0}).sort("timestamp", -1).limit(limit)
    docs = await cursor.to_list(length=limit)
    return docs[::-1]  # chronological order
