"""
Watsonx AI integration — server-side proxy so API keys never reach the browser.
Uses ibm-watsonx-ai SDK for text generation with SSE streaming.
"""

import json
from typing import AsyncGenerator

from ibm_watsonx_ai import Credentials
from ibm_watsonx_ai.foundation_models import ModelInference
from ibm_watsonx_ai.metanames import GenTextParamsMetaNames as Params

from app.config import settings


def _build_prompt(messages: list[dict]) -> str:
    """Convert message history to a plain-text prompt for Granite."""
    lines: list[str] = []
    for msg in messages:
        role = msg["role"].capitalize()
        lines.append(f"{role}: {msg['content']}")
    lines.append("Assistant:")
    return "\n".join(lines)


def _get_model() -> ModelInference:
    creds = Credentials(url=settings.watsonx_url, api_key=settings.watsonx_api_key)
    return ModelInference(
        model_id=settings.watsonx_model_id,
        project_id=settings.watsonx_project_id,
        credentials=creds,
        params={
            Params.MAX_NEW_TOKENS: 1024,
            Params.TEMPERATURE: 0.7,
            Params.DECODING_METHOD: "sample",
        },
    )


async def stream_response(messages: list[dict]) -> AsyncGenerator[str, None]:
    """
    Yields SSE-formatted data lines: `data: <chunk>\\n\\n`
    Yields `data: [DONE]\\n\\n` when finished.
    """
    prompt = _build_prompt(messages)
    model = _get_model()

    for response in model.generate_text_stream(prompt=prompt):
        # SDK returns str chunks
        chunk: str = response if isinstance(response, str) else json.dumps(response)
        if chunk:
            yield f"data: {chunk}\n\n"

    yield "data: [DONE]\n\n"
