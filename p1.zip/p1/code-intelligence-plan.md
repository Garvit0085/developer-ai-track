# AI-Driven Code Intelligence & Automated Documentation System — Implementation Plan

## Top-Level Overview

**Goal:** Build a small, beginner-friendly Streamlit application that lets a user upload a source-code file, statically analyse its structure, send it to IBM Watsonx (Granite model) for AI-generated explanations, and download the resulting technical documentation as a Markdown file.

**Scope:**
- Supported languages: Python, JavaScript, Java, C++
- File size limit: 50 KB
- Single-user, no authentication, no database, no cloud deployment
- AI calls are proxied through a dedicated service class — the Streamlit UI layer never touches the SDK directly
- All secrets live in a `.env` file loaded via `python-dotenv`

**Non-goals:** Streaming responses, multi-file uploads, syntax highlighting beyond `st.code()`, user accounts, persistent storage.

**Primary educational goals demonstrated:** Python OOP · AI integration · code analysis · automated documentation · Streamlit · separation of concerns · unit testing with pytest

---

## Sub-Task 1 — Project Scaffold & Configuration

**Status:** [ ] pending

**Intent:**
Establish the folder layout, dependency manifest, and configuration module so every subsequent sub-task has a stable foundation to build on.

**Expected Outcomes:**
- `code_intelligence/` package exists with an `__init__.py`
- `requirements.txt` lists all runtime dependencies
- `config.py` exposes typed constants loaded from `.env`
- `.env.example` documents every required env variable
- `tests/` directory exists with a placeholder `conftest.py`

**Todo List:**
1. Create the top-level directory layout as specified in the Project Structure section below.
2. Write `requirements.txt` with: `streamlit`, `ibm-watsonx-ai`, `python-dotenv`, `pytest`, `pytest-mock`.
3. Write `config.py` — a single `Settings` dataclass that reads `WATSONX_API_KEY`, `WATSONX_PROJECT_ID`, `WATSONX_URL`, `WATSONX_MODEL_ID` from `.env` via `python-dotenv`. Include `ALLOWED_EXTENSIONS: frozenset`, `MAX_FILE_SIZE_BYTES: int = 51200`.
4. Write `.env.example` listing all four Watsonx variables with placeholder values.
5. Add `.env` to `.gitignore`.
6. Create `tests/conftest.py` (empty for now — fixtures added later).

**Relevant Context:**
- `AGENTS.md` specifies `backend/.env` convention; mirror it here with a project-root `.env`
- `WATSONX_MODEL_ID` default value: `ibm/granite-3-3-8b-instruct`

---

## Sub-Task 2 — Custom Exceptions

**Status:** [ ] pending

**Intent:**
Define all application-specific exception classes in one place so every other module can import and raise them without circular dependencies.

**Expected Outcomes:**
- `exceptions.py` exists inside `code_intelligence/`
- Six exception classes are defined, each inheriting from a single `CodeIntelligenceError` base
- Each exception stores a human-readable `message` attribute

**Todo List:**
1. Create `code_intelligence/exceptions.py`.
2. Define base class `CodeIntelligenceError(Exception)`.
3. Define `InvalidFileTypeError`, `FileTooLargeError`, `EmptyFileError` (all file-validation exceptions).
4. Define `AIServiceError`, `AIResponseParseError` (AI-layer exceptions).
5. Define `UnsupportedLanguageError` (static-analysis exception).

**Relevant Context:**
- These map 1-to-1 to the exception table in the approved requirements analysis
- No exception should carry extra state beyond `message` — keep them flat

---

## Sub-Task 3 — Data Models

**Status:** [ ] pending

**Intent:**
Define the three typed data transfer objects that flow between layers so every module has a shared, explicit contract.

**Expected Outcomes:**
- `models.py` exists inside `code_intelligence/`
- Three `dataclass` definitions: `UploadedFile`, `CodeComponents`, `AIAnalysisResult`
- All fields are type-annotated; no field is mutable by default where immutability is appropriate

**Todo List:**
1. Create `code_intelligence/models.py`.
2. Define `UploadedFile` — fields: `filename: str`, `extension: str`, `raw_content: str`, `size_bytes: int`.
3. Define `CodeComponents` — fields: `language: str`, `imports: list[str]`, `functions: list[str]`, `classes: list[str]`, `line_count: int`.
4. Define `AIAnalysisResult` — fields: `overall_summary: str`, `component_summaries: dict[str, str]`, `architecture_description: str`, `raw_documentation: str`.
5. Use `@dataclass` (stdlib) — no Pydantic needed at this layer since there is no HTTP I/O.

**Relevant Context:**
- Field names match the Data Fields table in the approved requirements analysis exactly
- `component_summaries` maps a function/class name to a one-sentence description

---

## Sub-Task 4 — File Handler

**Status:** [ ] pending

**Intent:**
Implement the validation and reading of uploaded files, completely isolated from the UI, so it can be unit-tested without Streamlit.

**Expected Outcomes:**
- `file_handler.py` exists inside `code_intelligence/`
- `FileHandler` class with two public methods
- All six validation rules enforced with appropriate custom exceptions
- Unit tests pass in `tests/test_file_handler.py`

**Todo List:**
1. Create `code_intelligence/file_handler.py`.
2. Implement `FileHandler` class.
3. Implement `validate_file(filename: str, content_bytes: bytes) -> None` — raises the correct custom exception for each rule (wrong extension, too large, empty, non-UTF-8).
4. Implement `read_file_content(filename: str, content_bytes: bytes) -> UploadedFile` — calls `validate_file` first, then decodes to UTF-8 with `errors='replace'`, returns `UploadedFile`.
5. Create `tests/test_file_handler.py` — test each validation rule with a valid case and an invalid case.

**Relevant Context:**
- `ALLOWED_EXTENSIONS` and `MAX_FILE_SIZE_BYTES` come from `config.py` `Settings`
- Streamlit's `UploadedFile` object exposes `.name` and `.read()` — the handler receives raw `bytes`, not a Streamlit object, keeping it decoupled

---

## Sub-Task 5 — Code Analyzer

**Status:** [ ] pending

**Intent:**
Implement static code analysis that extracts functions, classes, and imports without calling the AI, so the UI can show structure immediately after upload.

**Expected Outcomes:**
- `code_analyzer.py` exists inside `code_intelligence/`
- `CodeAnalyzer` class with a single public entry point `extract_components`
- Python uses `ast`; JS/Java/C++ use regex fallback
- Unit tests pass in `tests/test_code_analyzer.py`

**Todo List:**
1. Create `code_intelligence/code_analyzer.py`.
2. Implement `CodeAnalyzer` class.
3. Implement `extract_components(code: str, language: str) -> CodeComponents` — dispatches to the correct private method.
4. Implement `_extract_python(code: str) -> CodeComponents` using `ast.parse`.
5. Implement `_extract_generic(code: str, language: str) -> CodeComponents` using regex patterns for function/class/import detection in JS, Java, C++.
6. Truncate `imports`, `functions`, and `classes` to 20 items each before returning (prompt safety rule from requirements).
7. Create `tests/test_code_analyzer.py` — test Python extraction with `ast`, test generic extraction with a small JS snippet, test empty code returns zeroed-out `CodeComponents`.

**Relevant Context:**
- `UnsupportedLanguageError` is raised only if `language` is not in `{'python', 'javascript', 'java', 'cpp'}`
- `line_count` is simply `len(code.splitlines())`
- Language string is derived from the file extension in `file_handler.py`

---

## Sub-Task 6 — AI Service

**Status:** [ ] pending

**Intent:**
Wrap all IBM Watsonx SDK calls in a single class so the UI layer is completely isolated from the AI SDK, credentials, and prompt engineering.

**Expected Outcomes:**
- `ai_service.py` exists inside `code_intelligence/`
- `AIService` class with one public method `analyze_code`
- Two private helpers: `_build_prompt` and `_parse_response`
- `AIServiceError` raised on SDK exceptions; `AIResponseParseError` on bad/empty response
- Unit tests pass in `tests/test_ai_service.py` using mocked SDK calls

**Todo List:**
1. Create `code_intelligence/ai_service.py`.
2. Implement `AIService` class — constructor accepts a `Settings` instance; initialises the Watsonx `ModelInference` client.
3. Implement `analyze_code(uploaded_file: UploadedFile, components: CodeComponents) -> AIAnalysisResult` — calls `_build_prompt`, calls the Watsonx model, calls `_parse_response`, returns `AIAnalysisResult`.
4. Implement `_build_prompt(uploaded_file: UploadedFile, components: CodeComponents) -> str` — constructs a structured prompt asking for: overall summary, per-component summaries (keyed by name), architecture description, and a full markdown documentation block.
5. Implement `_parse_response(raw: str) -> AIAnalysisResult` — parses the LLM text; if parsing fails or text is empty, falls back to placing the raw text in `overall_summary` and leaving other fields as empty strings/dicts.
6. Set a 30-second timeout on the Watsonx SDK call.
7. Create `tests/test_ai_service.py` — mock the Watsonx client; test successful parse, test empty response fallback, test SDK exception raises `AIServiceError`.

**Relevant Context:**
- SDK class to use: `ibm_watsonx_ai.foundation_models.ModelInference`
- Parameters: `model_id`, `credentials` (dict with `url` + `apikey`), `project_id`
- Generation params: `max_new_tokens=1024`, `temperature=0.2` (deterministic documentation output)
- The prompt must instruct the model to respond in clearly delimited sections so `_parse_response` can split on known headers

---

## Sub-Task 7 — Documentation Builder

**Status:** [ ] pending

**Intent:**
Assemble the static analysis results and AI output into a single, well-formatted Markdown document that the user can download.

**Expected Outcomes:**
- `doc_builder.py` exists inside `code_intelligence/`
- `DocBuilder` class with one public method `build_documentation`
- Output is a valid, human-readable Markdown string
- Unit tests pass in `tests/test_doc_builder.py`

**Todo List:**
1. Create `code_intelligence/doc_builder.py`.
2. Implement `DocBuilder` class.
3. Implement `build_documentation(components: CodeComponents, ai_result: AIAnalysisResult, filename: str) -> str` — builds and returns the full Markdown string.
4. Document sections to include: title, file metadata (language, line count), overall summary, component table (imports/functions/classes), per-component AI summaries, architecture description, full raw AI documentation block.
5. Implement private `_format_component_table(components: CodeComponents) -> str` helper.
6. Create `tests/test_doc_builder.py` — assert that the output contains the filename, that all sections are present, and that component names appear in the output.

**Relevant Context:**
- The `raw_documentation` field from `AIAnalysisResult` is appended verbatim at the end under a `## Full AI-Generated Documentation` heading
- If a field is empty (e.g. no classes found), that section is labelled `_None detected_` rather than omitted

---

## Sub-Task 8 — Streamlit UI

**Status:** [ ] pending

**Intent:**
Build the single-page Streamlit interface that wires all service classes together and presents the results to the user. The UI contains zero business logic.

**Expected Outcomes:**
- `app.py` exists at project root
- Upload → static analysis → AI analysis → download flow works end-to-end
- All `CodeIntelligenceError` subclasses are caught and shown as `st.error()` messages
- Download button only appears after successful documentation generation
- Analyze button is disabled while the AI call is in progress

**Todo List:**
1. Create `app.py` at project root.
2. Set up `st.set_page_config` with a meaningful title and wide layout.
3. Implement `render_upload_section() -> UploadedFile | None` — `st.file_uploader` filtered to allowed extensions; calls `FileHandler.read_file_content`; returns `UploadedFile` or `None`.
4. Implement `render_code_display(uploaded_file: UploadedFile)` — shows `st.code(raw_content, language=...)`.
5. Implement `render_components(components: CodeComponents)` — shows three `st.expander` blocks (Imports, Functions, Classes) plus line count metric.
6. Implement `render_analysis_results(ai_result: AIAnalysisResult)` — shows overall summary, per-component summaries, architecture description.
7. Implement `render_download_button(doc_content: str, filename: str)` — `st.download_button` for the `.md` file.
8. Wire the main flow in `if __name__ == "__main__"` block using `st.session_state` to store `UploadedFile`, `CodeComponents`, `AIAnalysisResult`, and `doc_content` across reruns.
9. Wrap every service call in a `try/except CodeIntelligenceError as e: st.error(e.message)`.

**Relevant Context:**
- Static analysis runs immediately on upload (no button click needed)
- AI analysis runs only on explicit `st.button("Analyse Code")` click
- `st.spinner("Analysing with Watsonx...")` wraps the `AIService.analyze_code` call
- Language string for `st.code()` is derived from `UploadedFile.extension`: `.py` → `"python"`, `.js` → `"javascript"`, `.java` → `"java"`, `.cpp` → `"cpp"`

---

## Sub-Task 9 — Integration Smoke Test & README

**Status:** [ ] pending

**Intent:**
Verify the end-to-end flow works with a real (or mocked) Watsonx call and document how to run the project.

**Expected Outcomes:**
- `README.md` covers: setup, `.env` configuration, running the app, running tests
- A `tests/test_integration.py` file with one smoke-test that exercises `FileHandler → CodeAnalyzer → DocBuilder` without calling the real AI (AI is mocked)
- All `pytest` tests pass with `pytest tests/`

**Todo List:**
1. Write `README.md` with: prerequisites, `pip install -r requirements.txt`, `.env` setup instructions, `streamlit run app.py`, `pytest tests/`.
2. Create `tests/test_integration.py` — load a fixture Python file, run `FileHandler` → `CodeAnalyzer` → `DocBuilder` with a mocked `AIAnalysisResult`, assert final Markdown contains expected strings.
3. Run `pytest tests/` and confirm all tests pass.

**Relevant Context:**
- No live Watsonx credentials are needed for the test suite — all AI calls are mocked via `pytest-mock`
- Fixture files (small `.py`, `.js` snippets) live in `tests/fixtures/`

---

## Project Structure

```
project-root/
│
├── app.py                          # Streamlit entry point — UI only
├── requirements.txt
├── .env                            # Secrets — never committed
├── .env.example                    # Template — committed
├── .gitignore
├── README.md
│
├── code_intelligence/              # Core business logic package
│   ├── __init__.py
│   ├── config.py                   # Settings dataclass + dotenv loading
│   ├── exceptions.py               # All custom exception classes
│   ├── models.py                   # UploadedFile, CodeComponents, AIAnalysisResult
│   ├── file_handler.py             # FileHandler class
│   ├── code_analyzer.py            # CodeAnalyzer class
│   ├── ai_service.py               # AIService class (Watsonx SDK wrapper)
│   └── doc_builder.py              # DocBuilder class
│
└── tests/
    ├── conftest.py
    ├── fixtures/
    │   ├── sample.py
    │   └── sample.js
    ├── test_file_handler.py
    ├── test_code_analyzer.py
    ├── test_ai_service.py
    ├── test_doc_builder.py
    └── test_integration.py
```

---

## Data Flow

```
User uploads file
      │
      ▼
FileHandler.read_file_content()
      │  returns UploadedFile
      ▼
CodeAnalyzer.extract_components()
      │  returns CodeComponents
      ▼
[displayed immediately in UI]
      │
      │  user clicks "Analyse Code"
      ▼
AIService.analyze_code()
      │  returns AIAnalysisResult
      ▼
DocBuilder.build_documentation()
      │  returns str (Markdown)
      ▼
st.download_button()  ←  results rendered in UI
```

---

## Assumptions

1. The Watsonx Granite model responds in plain text with section headers that `_parse_response` can split on — the exact delimiter strings are established during Sub-Task 6.
2. A single `.env` file at project root is sufficient; no multi-environment config is needed.
3. Streamlit `session_state` is the only persistence mechanism — a page refresh clears all results, and this is acceptable for a beginner project.
4. The `ast` module is used only for Python; all other languages use regex — accuracy for non-Python languages is best-effort.
5. pytest-mock is used to mock the Watsonx SDK; no real API calls are made during the test suite.
6. The project runs locally only (`streamlit run app.py`) — no containerisation or deployment configuration is included.
7. `ibm-watsonx-ai` SDK version used is whatever is current at implementation time; pin it in `requirements.txt` after installation.
