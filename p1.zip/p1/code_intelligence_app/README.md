# AI-Driven Code Intelligence & Automated Documentation System

A beginner-friendly Streamlit application that analyses source-code files using static parsing and IBM Watsonx AI (Granite model) to generate plain-English explanations and downloadable Markdown documentation.

---

## Features

- Upload `.py`, `.js`, `.java`, `.cpp`, or `.c` files (max 50 KB)
- Instant static structure analysis — functions, classes, imports, line count
- AI-generated code explanation (plain English, beginner-friendly)
- Per-component purpose summaries
- Architecture / system diagram description (with optional Mermaid diagram)
- One-click download of generated documentation as a `.md` file
- Graceful handling of all error conditions

---

## Prerequisites

- Python 3.11 or later
- An IBM Watsonx account with an API key and a project ID ([sign up free](https://www.ibm.com/watsonx))

---

## Installation

```bash
# 1. Clone or download the project
cd code_intelligence_app

# 2. (Recommended) Create a virtual environment
python -m venv .venv
source .venv/bin/activate        # Linux / macOS
.venv\Scripts\activate           # Windows

# 3. Install dependencies
pip install -r requirements.txt
```

---

## Configuration

Copy the example environment file and fill in your credentials:

```bash
cp .env.example .env
```

Edit `.env`:

```env
WATSONX_API_KEY=your_ibm_watsonx_api_key_here
WATSONX_PROJECT_ID=your_project_id_here
WATSONX_URL=https://us-south.ml.cloud.ibm.com
WATSONX_MODEL_ID=ibm/granite-3-3-8b-instruct
```

> **Never commit your `.env` file.** It is already listed in `.gitignore`.

The static code analysis works without credentials.  
AI features are disabled until valid credentials are provided.

---

## Running the Application

```bash
streamlit run app.py
```

Open your browser at **http://localhost:8501**.

---

## Running the Tests

```bash
pytest tests/ -v
```

All tests mock the Watsonx SDK — no real API key is required to run the test suite.

---

## Project Structure

```
code_intelligence_app/
├── app.py                          # Streamlit UI (presentation only)
├── requirements.txt
├── .env.example                    # Credentials template
├── README.md
│
├── code_intelligence/              # Core business logic package
│   ├── __init__.py
│   ├── config.py                   # Settings dataclass
│   ├── exceptions.py               # Custom exception hierarchy
│   ├── models.py                   # UploadedFile, CodeComponents, AIAnalysisResult
│   ├── file_handler.py             # File validation and reading
│   ├── code_analyzer.py            # Static code structure analysis
│   ├── ai_service.py               # IBM Watsonx SDK wrapper
│   └── doc_builder.py              # Markdown documentation assembler
│
└── tests/
    ├── conftest.py                 # Shared fixtures
    ├── test_file_handler.py
    ├── test_code_analyzer.py
    ├── test_ai_service.py
    ├── test_doc_builder.py
    └── test_integration.py
```

---

## Architecture

```
User uploads file
      │
      ▼
FileHandler.read_file_content()   — validates extension, size, encoding
      │  UploadedFile
      ▼
CodeAnalyzer.extract_components() — ast (Python) / regex (others)
      │  CodeComponents
      ▼
[UI renders structure immediately]
      │
      │  user clicks "Analyse Code with AI"
      ▼
AIService.analyze_code()          — Watsonx Granite API call
      │  AIAnalysisResult
      ▼
DocBuilder.build_documentation()  — assembles Markdown
      │  str
      ▼
st.download_button()
```

---

## Limitations and Assumptions

- **Non-Python languages** use regex-based analysis — accuracy is best-effort.
- **File size limit** is 50 KB. Larger files are rejected to stay within LLM token limits.
- **No streaming** — the UI waits for the full AI response (typically 5–15 seconds).
- **Session state only** — results are cleared on page refresh; no database is used.
- **Mermaid diagrams** are shown as code blocks with a link to mermaid.live for rendering.
- The AI model may not always follow the expected response format; the parser falls back gracefully.
- Uploaded code is **never executed** — it is always treated as plain text.

---

## Security Notes

- API keys are stored in `.env` only — never in source code or the Streamlit UI.
- Uploaded files are treated strictly as text; `eval()`, `exec()`, and similar mechanisms are never called on uploaded content.
- CORS and authentication are out of scope for this local educational project.
