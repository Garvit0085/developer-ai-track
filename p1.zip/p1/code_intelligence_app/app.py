"""
app.py — Streamlit UI entry point.

This file contains ONLY presentation logic.  It calls the service classes
from ``code_intelligence`` and renders their outputs.  No business logic,
no AI SDK imports, no direct file parsing live here.

Run with:
    streamlit run app.py
"""
from __future__ import annotations

import streamlit as st

from code_intelligence.ai_service import AIService
from code_intelligence.code_analyzer import CodeAnalyzer
from code_intelligence.config import Settings
from code_intelligence.doc_builder import DocBuilder
from code_intelligence.exceptions import AIServiceError, CodeIntelligenceError
from code_intelligence.file_handler import FileHandler
from code_intelligence.models import AIAnalysisResult, CodeComponents, UploadedFile

# ---------------------------------------------------------------------------
# Page configuration (must be the first Streamlit call)
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="Code Intelligence",
    page_icon="🧠",
    layout="wide",
)

# ---------------------------------------------------------------------------
# Singleton service instances (created once per session)
# ---------------------------------------------------------------------------
_settings = Settings()
_file_handler = FileHandler(_settings)
_analyzer = CodeAnalyzer()
_doc_builder = DocBuilder()
_ai_service = AIService(_settings)


# ---------------------------------------------------------------------------
# Helper renderers
# ---------------------------------------------------------------------------

def _render_header() -> None:
    st.title("🧠 AI-Driven Code Intelligence")
    st.markdown(
        "Upload a source-code file to get an instant structure analysis "
        "and an AI-generated explanation and documentation."
    )
    st.divider()


def _render_upload_section() -> UploadedFile | None:
    """Render the file uploader and return a validated ``UploadedFile`` or ``None``."""
    allowed = sorted(_settings.allowed_extensions)
    # Strip dots for Streamlit's ``type`` parameter.
    types_no_dot = [ext.lstrip(".") for ext in allowed]

    uploaded = st.file_uploader(
        "Upload a source-code file",
        type=types_no_dot,
        help=f"Supported types: {', '.join(allowed)} — max 50 KB",
    )

    if uploaded is None:
        return None

    try:
        content_bytes: bytes = uploaded.read()
        code_file = _file_handler.read_file_content(uploaded.name, content_bytes)
        return code_file
    except CodeIntelligenceError as exc:
        st.error(f"⛔ {exc.message}")
        return None


def _render_code_display(code_file: UploadedFile) -> None:
    """Show the source code in a syntax-highlighted block."""
    language = FileHandler.extension_to_language(code_file.extension)
    with st.expander("📄 Source Code", expanded=True):
        st.code(code_file.raw_content, language=language)
    st.caption(
        f"**{code_file.filename}** — "
        f"{code_file.size_bytes / 1024:.1f} KB · "
        f"{FileHandler.extension_to_language(code_file.extension).capitalize()}"
    )


def _render_components(components: CodeComponents) -> None:
    """Display the static-analysis results in three expandable sections."""
    st.subheader("🔍 Code Structure", divider="blue")

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Lines", components.line_count)
    col2.metric("Functions", len(components.functions))
    col3.metric("Classes", len(components.classes))
    col4.metric("Imports", len(components.imports))

    col_left, col_right = st.columns(2)

    with col_left:
        with st.expander(f"📦 Imports ({len(components.imports)})", expanded=False):
            if components.imports:
                for imp in components.imports:
                    st.code(imp, language="text")
            else:
                st.info("No imports detected.")

        with st.expander(f"🏛️ Classes ({len(components.classes)})", expanded=False):
            if components.classes:
                for cls in components.classes:
                    st.code(cls, language="text")
            else:
                st.info("No classes detected.")

    with col_right:
        with st.expander(f"⚙️ Functions ({len(components.functions)})", expanded=False):
            if components.functions:
                for fn in components.functions:
                    st.code(fn, language="text")
            else:
                st.info("No functions detected.")


def _render_analysis_results(ai_result: AIAnalysisResult) -> None:
    """Render the AI-generated analysis sections."""
    st.subheader("💡 AI Code Explanation", divider="green")
    st.markdown(ai_result.overall_summary or "_No summary generated._")

    if ai_result.component_summaries:
        st.subheader("📖 Component Explanations", divider="green")
        for name, description in ai_result.component_summaries.items():
            with st.expander(f"`{name}`"):
                st.markdown(description)

    if ai_result.architecture_description:
        st.subheader("🏗️ Architecture / System Diagram", divider="green")
        # Check if the description contains a Mermaid block and render it.
        desc = ai_result.architecture_description
        if "```mermaid" in desc:
            before, _, after = desc.partition("```mermaid")
            mermaid_block, _, rest = after.partition("```")
            if before.strip():
                st.markdown(before.strip())
            st.code(mermaid_block.strip(), language="text")
            st.caption(
                "💡 Paste the diagram above at https://mermaid.live to visualise it."
            )
            if rest.strip():
                st.markdown(rest.strip())
        else:
            st.markdown(desc)


def _render_download_button(doc_content: str, filename: str) -> None:
    """Show a download button for the generated Markdown documentation."""
    stem = filename.rsplit(".", 1)[0] if "." in filename else filename
    download_name = f"{stem}_documentation.md"

    st.download_button(
        label="⬇️ Download Documentation (.md)",
        data=doc_content,
        file_name=download_name,
        mime="text/markdown",
        type="primary",
    )


def _render_credentials_warning() -> None:
    """Warn the user if Watsonx credentials are not configured."""
    st.warning(
        "⚠️ **Watsonx credentials are not configured.** "
        "The code structure analysis will work, but AI-powered explanations "
        "and documentation generation will be unavailable. "
        "See `.env.example` for setup instructions.",
        icon="⚠️",
    )


# ---------------------------------------------------------------------------
# Main application flow
# ---------------------------------------------------------------------------

def main() -> None:
    _render_header()

    # ── Sidebar: credential status ──────────────────────────────────────────
    with st.sidebar:
        st.header("ℹ️ About")
        st.markdown(
            "This tool analyses source-code files using static parsing "
            "and IBM Watsonx AI to generate beginner-friendly explanations "
            "and downloadable documentation."
        )
        st.divider()
        if _settings.has_ai_credentials():
            st.success("✅ Watsonx credentials configured")
        else:
            st.error("❌ Watsonx credentials missing")
        st.caption(f"Model: `{_settings.watsonx_model_id}`")

    # ── Warn about missing credentials ──────────────────────────────────────
    if not _settings.has_ai_credentials():
        _render_credentials_warning()

    # ── File upload ──────────────────────────────────────────────────────────
    code_file = _render_upload_section()

    if code_file is None:
        st.info("👆 Upload a source-code file to get started.")
        return

    # ── Display source code ──────────────────────────────────────────────────
    _render_code_display(code_file)

    # ── Static code analysis (runs immediately on upload) ───────────────────
    try:
        language = FileHandler.extension_to_language(code_file.extension)
        components: CodeComponents = _analyzer.extract_components(
            code_file.raw_content, language
        )
    except CodeIntelligenceError as exc:
        st.error(f"⛔ {exc.message}")
        return

    _render_components(components)
    st.divider()

    # ── AI analysis (triggered by button click) ──────────────────────────────
    if not _settings.has_ai_credentials():
        st.info(
            "🔒 AI analysis is disabled — add your Watsonx credentials to enable it."
        )
        return

    if st.button("🚀 Analyse Code with AI", type="primary", use_container_width=True):
        st.session_state["ai_result"] = None
        st.session_state["doc_content"] = None

        with st.spinner("🤖 Analysing with Watsonx Granite..."):
            try:
                ai_result: AIAnalysisResult = _ai_service.analyze_code(
                    code_file, components
                )
                doc_content: str = _doc_builder.build_documentation(
                    components, ai_result, code_file.filename
                )
                st.session_state["ai_result"] = ai_result
                st.session_state["doc_content"] = doc_content
            except AIServiceError as exc:
                st.error(f"⛔ AI Service Error: {exc.message}")
                return
            except CodeIntelligenceError as exc:
                st.error(f"⛔ {exc.message}")
                return

    # ── Render AI results (persisted in session state across reruns) ─────────
    ai_result = st.session_state.get("ai_result")
    doc_content = st.session_state.get("doc_content")

    if ai_result is not None:
        _render_analysis_results(ai_result)
        st.divider()

    if doc_content:
        st.subheader("📥 Download Documentation", divider="grey")
        _render_download_button(doc_content, code_file.filename)

        with st.expander("Preview generated documentation"):
            st.markdown(doc_content)


if __name__ == "__main__":
    main()
