"""
Package initialiser for code_intelligence.

Exposes the public API so callers can do:
    from code_intelligence import FileHandler, CodeAnalyzer, AIService, DocBuilder
"""
from code_intelligence.config import Settings
from code_intelligence.exceptions import (
    CodeIntelligenceError,
    InvalidFileTypeError,
    FileTooLargeError,
    EmptyFileError,
    AIServiceError,
    AIResponseParseError,
    UnsupportedLanguageError,
)
from code_intelligence.models import UploadedFile, CodeComponents, AIAnalysisResult
from code_intelligence.file_handler import FileHandler
from code_intelligence.code_analyzer import CodeAnalyzer
from code_intelligence.ai_service import AIService
from code_intelligence.doc_builder import DocBuilder

__all__ = [
    "Settings",
    "CodeIntelligenceError",
    "InvalidFileTypeError",
    "FileTooLargeError",
    "EmptyFileError",
    "AIServiceError",
    "AIResponseParseError",
    "UnsupportedLanguageError",
    "UploadedFile",
    "CodeComponents",
    "AIAnalysisResult",
    "FileHandler",
    "CodeAnalyzer",
    "AIService",
    "DocBuilder",
]
