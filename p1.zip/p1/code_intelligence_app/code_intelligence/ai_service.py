"""
AIService — wraps IBM Watsonx SDK calls.

All communication with the external LLM lives here.  The Streamlit UI and
every other module must *never* import ``ibm_watsonx_ai`` directly — they
always go through this class.  This makes the AI layer easy to mock in
unit tests and easy to swap for a different provider later.

Prompt design
─────────────
The model is asked to reply using four clearly-labelled sections separated
by ``---SECTION---`` delimiters so that ``_parse_response`` can split the
text reliably without complex NLP.  If the model returns something
unexpected, the parser falls back gracefully.
"""
from __future__ import annotations

from code_intelligence.config import Settings
from code_intelligence.exceptions import AIResponseParseError, AIServiceError
from code_intelligence.models import AIAnalysisResult, CodeComponents, UploadedFile

# Section delimiter the model is instructed to use.
_SECTION_DELIMITER = "---SECTION---"

# Section names in the expected order.
_SECTION_OVERALL = "OVERALL SUMMARY"
_SECTION_COMPONENTS = "COMPONENT SUMMARIES"
_SECTION_ARCHITECTURE = "ARCHITECTURE DESCRIPTION"
_SECTION_DOCUMENTATION = "FULL DOCUMENTATION"


class AIService:
    """Communicates with the IBM Watsonx Granite model.

    Args:
        settings: Application settings containing Watsonx credentials.
                  Defaults to a freshly constructed ``Settings()`` instance.

    Raises:
        AIServiceError: Raised during construction if credentials are missing,
                        or during ``analyze_code`` if the SDK call fails.
    """

    def __init__(self, settings: Settings | None = None) -> None:
        self._settings: Settings = settings or Settings()
        self._model = self._init_model()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def analyze_code(
        self, uploaded_file: UploadedFile, components: CodeComponents
    ) -> AIAnalysisResult:
        """Send the source code to Watsonx and return a structured analysis.

        Args:
            uploaded_file: The validated source-code file.
            components:    Static-analysis results (functions, classes, etc.).

        Returns:
            An :class:`~code_intelligence.models.AIAnalysisResult`.

        Raises:
            AIServiceError:       The SDK call failed (network, auth, timeout).
            AIResponseParseError: The model response was empty or malformed.
        """
        prompt = self._build_prompt(uploaded_file, components)
        raw_response = self._call_model(prompt)
        return self._parse_response(raw_response)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _init_model(self):  # type: ignore[return]
        """Initialise and return the Watsonx ``ModelInference`` client.

        Returns ``None`` when credentials are missing so the app can start
        without a configured API key and surface a friendly error only when
        the user actually clicks *Analyse Code*.
        """
        if not self._settings.has_ai_credentials():
            return None

        try:
            from ibm_watsonx_ai import Credentials
            from ibm_watsonx_ai.foundation_models import ModelInference

            credentials = Credentials(
                url=self._settings.watsonx_url,
                api_key=self._settings.watsonx_api_key,
            )
            return ModelInference(
                model_id=self._settings.watsonx_model_id,
                credentials=credentials,
                project_id=self._settings.watsonx_project_id,
                params={
                    "max_new_tokens": 1024,
                    "temperature": 0.2,
                },
            )
        except Exception as exc:  # noqa: BLE001
            raise AIServiceError(
                f"Failed to initialise Watsonx client: {exc}"
            ) from exc

    def _call_model(self, prompt: str) -> str:
        """Call the Watsonx model and return the raw text response.

        Args:
            prompt: The fully-constructed prompt string.

        Returns:
            Raw text string returned by the model.

        Raises:
            AIServiceError: Credentials missing or SDK call failed.
        """
        if self._model is None:
            raise AIServiceError(
                "Watsonx credentials are not configured. "
                "Please set WATSONX_API_KEY and WATSONX_PROJECT_ID in your .env file."
            )
        try:
            response = self._model.generate_text(prompt=prompt)
            return str(response) if response else ""
        except Exception as exc:  # noqa: BLE001
            raise AIServiceError(
                f"Watsonx API call failed: {exc}"
            ) from exc

    def _build_prompt(
        self, uploaded_file: UploadedFile, components: CodeComponents
    ) -> str:
        """Construct the structured prompt sent to the model.

        The prompt instructs the model to reply in four named sections
        separated by ``---SECTION---`` so the response can be parsed
        deterministically.
        """
        functions_str = (
            ", ".join(components.functions) if components.functions else "none detected"
        )
        classes_str = (
            ", ".join(components.classes) if components.classes else "none detected"
        )
        imports_str = (
            ", ".join(components.imports) if components.imports else "none detected"
        )

        # Truncate very large files to avoid exceeding the model's token limit.
        code_snippet = uploaded_file.raw_content
        if len(code_snippet) > 6000:
            code_snippet = code_snippet[:6000] + "\n... [truncated for brevity]"

        return f"""You are a senior software engineer helping a beginner understand source code.

Analyse the following {components.language} source code and respond using EXACTLY four sections in order, each preceded by the delimiter line "{_SECTION_DELIMITER}" and its section name on the next line.

Source file: {uploaded_file.filename}
Language: {components.language}
Lines of code: {components.line_count}
Functions detected: {functions_str}
Classes detected: {classes_str}
Imports detected: {imports_str}

Source code:
```
{code_snippet}
```

---
Reply format — use EXACTLY this structure, do NOT add extra delimiters:

{_SECTION_DELIMITER}
{_SECTION_OVERALL}
Write 2-4 sentences explaining what this code does in plain English for a beginner.

{_SECTION_DELIMITER}
{_SECTION_COMPONENTS}
For each function and class listed above, write one sentence explaining its purpose.
Format each line as:  name: description

{_SECTION_DELIMITER}
{_SECTION_ARCHITECTURE}
Describe the high-level architecture or data flow in 2-3 sentences.
If the code is simple enough, also provide a Mermaid flowchart (inside a ```mermaid block).

{_SECTION_DELIMITER}
{_SECTION_DOCUMENTATION}
Write complete technical documentation in Markdown format including:
- ## Overview
- ## Dependencies
- ## Components (functions and classes with brief descriptions)
- ## Usage Example
"""

    def _parse_response(self, raw: str) -> AIAnalysisResult:
        """Parse the model's raw text into a structured ``AIAnalysisResult``.

        If the expected delimiters are not found, the entire raw text is
        placed in ``overall_summary`` so the user always sees *something*
        rather than an empty result.

        Args:
            raw: Raw text returned by ``_call_model``.

        Returns:
            A populated :class:`~code_intelligence.models.AIAnalysisResult`.
        """
        if not raw or not raw.strip():
            raise AIResponseParseError(
                "The AI model returned an empty response. Please try again."
            )

        # Split on the section delimiter line.
        parts = [p.strip() for p in raw.split(_SECTION_DELIMITER) if p.strip()]

        if len(parts) < 2:
            # Model did not follow the format — return raw text as summary.
            return AIAnalysisResult(
                overall_summary=raw.strip(),
                component_summaries={},
                architecture_description="",
                raw_documentation="",
            )

        sections: dict[str, str] = {}
        for part in parts:
            lines = part.splitlines()
            if not lines:
                continue
            section_name = lines[0].strip()
            section_body = "\n".join(lines[1:]).strip()
            sections[section_name] = section_body

        overall = sections.get(_SECTION_OVERALL, raw.strip())
        architecture = sections.get(_SECTION_ARCHITECTURE, "")
        documentation = sections.get(_SECTION_DOCUMENTATION, "")

        # Parse component summaries: each line should be "name: description"
        component_summaries: dict[str, str] = {}
        raw_components = sections.get(_SECTION_COMPONENTS, "")
        for line in raw_components.splitlines():
            if ":" in line:
                name, _, description = line.partition(":")
                name = name.strip()
                description = description.strip()
                if name and description:
                    component_summaries[name] = description

        return AIAnalysisResult(
            overall_summary=overall,
            component_summaries=component_summaries,
            architecture_description=architecture,
            raw_documentation=documentation,
        )
