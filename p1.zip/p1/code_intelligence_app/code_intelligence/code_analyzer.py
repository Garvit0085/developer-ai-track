"""
CodeAnalyzer — static code-structure analysis without AI.

For Python files the stdlib ``ast`` module is used for accurate symbol
extraction.  For all other supported languages (JavaScript, Java, C, C++)
a set of regular-expression patterns provides best-effort extraction that
is good enough for a beginner project.

The analyser runs immediately after file upload so the user sees the code
structure without waiting for an AI call.
"""
from __future__ import annotations

import ast
import re

from code_intelligence.exceptions import UnsupportedLanguageError
from code_intelligence.models import CodeComponents

# Maximum number of items to keep per component list.
# Prevents excessively long prompts when the file has many symbols.
_MAX_ITEMS = 20

# Languages handled by the regex fallback path.
_SUPPORTED_LANGUAGES = frozenset({"python", "javascript", "java", "cpp", "c"})

# ---------------------------------------------------------------------------
# Regex patterns for non-Python languages (best-effort)
# ---------------------------------------------------------------------------
_PATTERNS: dict[str, dict[str, str]] = {
    "javascript": {
        "functions": (
            r"(?:function\s+(\w+)"                   # function foo(
            r"|(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?\(.*?\)\s*=>"  # const foo = () =>
            r"|(\w+)\s*:\s*(?:async\s*)?function)"   # foo: function
        ),
        "classes": r"class\s+(\w+)",
        "imports": r'(?:import\s+.*?from\s+["\'](.+?)["\']|require\s*\(\s*["\'](.+?)["\']\s*\))',
    },
    "java": {
        "functions": r"(?:public|private|protected|static|\s)\s+\w[\w<>\[\]]*\s+(\w+)\s*\(",
        "classes": r"(?:class|interface|enum)\s+(\w+)",
        "imports": r"import\s+([\w.]+)\s*;",
    },
    "cpp": {
        "functions": r"[\w:*&<>]+\s+(\w+)\s*\([^)]*\)\s*(?:const\s*)?\{",
        "classes": r"(?:class|struct)\s+(\w+)",
        "imports": r"#include\s*[<\"]([^>\"]+)[>\"]",
    },
    "c": {
        "functions": r"[\w*]+\s+(\w+)\s*\([^)]*\)\s*\{",
        "classes": r"(?:struct|union|enum)\s+(\w+)",
        "imports": r"#include\s*[<\"]([^>\"]+)[>\"]",
    },
}


class CodeAnalyzer:
    """Extracts structural components from source code without calling AI.

    Usage::

        analyzer = CodeAnalyzer()
        components = analyzer.extract_components(code, "python")
    """

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def extract_components(self, code: str, language: str) -> CodeComponents:
        """Extract classes, functions, and imports from source code.

        Args:
            code:     Raw source-code string.
            language: Normalised language name (e.g. ``"python"``).

        Returns:
            A :class:`~code_intelligence.models.CodeComponents` instance.

        Raises:
            UnsupportedLanguageError: ``language`` is not in the supported set.
        """
        normalised = language.lower().strip()
        if normalised not in _SUPPORTED_LANGUAGES:
            raise UnsupportedLanguageError(
                f"Language '{language}' is not supported for static analysis. "
                f"Supported languages: {', '.join(sorted(_SUPPORTED_LANGUAGES))}"
            )

        if not code.strip():
            return CodeComponents(language=normalised, line_count=0)

        if normalised == "python":
            return self._extract_python(code)
        return self._extract_generic(code, normalised)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _extract_python(self, code: str) -> CodeComponents:
        """Use the stdlib ``ast`` module to extract Python symbols accurately."""
        imports: list[str] = []
        functions: list[str] = []
        classes: list[str] = []

        try:
            tree = ast.parse(code)
        except SyntaxError:
            # If the file has syntax errors, fall back to regex extraction.
            return self._extract_generic(code, "python")

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    imports.append(alias.name)
            elif isinstance(node, ast.ImportFrom):
                module = node.module or ""
                names = ", ".join(a.name for a in node.names)
                imports.append(f"from {module} import {names}")
            elif isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                functions.append(node.name)
            elif isinstance(node, ast.ClassDef):
                classes.append(node.name)

        return CodeComponents(
            language="python",
            imports=imports[:_MAX_ITEMS],
            functions=functions[:_MAX_ITEMS],
            classes=classes[:_MAX_ITEMS],
            line_count=len(code.splitlines()),
        )

    def _extract_generic(self, code: str, language: str) -> CodeComponents:
        """Use regex patterns to extract symbols from non-Python languages."""
        patterns = _PATTERNS.get(language, {})

        functions = self._find_all_groups(patterns.get("functions", ""), code)
        classes = self._find_all_groups(patterns.get("classes", ""), code)
        imports = self._find_all_groups(patterns.get("imports", ""), code)

        return CodeComponents(
            language=language,
            imports=imports[:_MAX_ITEMS],
            functions=functions[:_MAX_ITEMS],
            classes=classes[:_MAX_ITEMS],
            line_count=len(code.splitlines()),
        )

    @staticmethod
    def _find_all_groups(pattern: str, code: str) -> list[str]:
        """Return all non-empty captured groups from *all* matches of *pattern*."""
        if not pattern:
            return []
        results: list[str] = []
        for match in re.finditer(pattern, code, re.MULTILINE):
            # A pattern may have multiple capture groups; keep the first non-empty one.
            captured = next((g for g in match.groups() if g), None)
            if captured:
                results.append(captured.strip())
        # Deduplicate while preserving order.
        seen: set[str] = set()
        unique: list[str] = []
        for item in results:
            if item not in seen:
                seen.add(item)
                unique.append(item)
        return unique
