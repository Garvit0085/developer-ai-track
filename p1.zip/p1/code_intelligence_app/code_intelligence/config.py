"""
Application configuration.

Reads all settings from a .env file (or real environment variables) via
python-dotenv.  A single Settings dataclass is the single source of truth
for every constant used across the application.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field

from dotenv import load_dotenv

# Load .env file once when this module is first imported.
load_dotenv()

# ---------------------------------------------------------------------------
# Language → extension mapping (used by FileHandler and the UI)
# ---------------------------------------------------------------------------
EXTENSION_TO_LANGUAGE: dict[str, str] = {
    ".py": "python",
    ".js": "javascript",
    ".java": "java",
    ".cpp": "cpp",
    ".c": "c",
}


@dataclass(frozen=True)
class Settings:
    """All application-wide constants, loaded from environment variables."""

    watsonx_api_key: str = field(
        default_factory=lambda: os.getenv("WATSONX_API_KEY", "")
    )
    watsonx_project_id: str = field(
        default_factory=lambda: os.getenv("WATSONX_PROJECT_ID", "")
    )
    watsonx_url: str = field(
        default_factory=lambda: os.getenv(
            "WATSONX_URL", "https://us-south.ml.cloud.ibm.com"
        )
    )
    watsonx_model_id: str = field(
        default_factory=lambda: os.getenv(
            "WATSONX_MODEL_ID", "ibm/granite-3-3-8b-instruct"
        )
    )
    allowed_extensions: frozenset[str] = field(
        default_factory=lambda: frozenset(EXTENSION_TO_LANGUAGE.keys())
    )
    max_file_size_bytes: int = 51_200  # 50 KB

    def has_ai_credentials(self) -> bool:
        """Return True only when both the API key and project ID are set."""
        return bool(self.watsonx_api_key) and bool(self.watsonx_project_id)
