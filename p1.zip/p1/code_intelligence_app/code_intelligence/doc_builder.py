"""
DocBuilder — assembles static-analysis results and AI output into a
downloadable Markdown document.

This class contains no business logic beyond formatting.  It takes the
two data objects produced by ``CodeAnalyzer`` and ``AIService`` and
produces a clean, human-readable Markdown string the user can download.
"""
from __future__ import annotations

from datetime import datetime

from code_intelligence.models import AIAnalysisResult, CodeComponents


class DocBuilder:
    """Assembles the final Markdown documentation file.

    Usage::

        builder = DocBuilder()
        markdown = builder.build_documentation(components, ai_result, "main.py")
    """

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def build_documentation(
        self,
        components: CodeComponents,
        ai_result: AIAnalysisResult,
        filename: str,
    ) -> str:
        """Build and return the full Markdown documentation string.

        Args:
            components: Static-analysis results (language, imports, etc.).
            ai_result:  AI-generated analysis results.
            filename:   Original filename of the uploaded source-code file.

        Returns:
            A complete, well-structured Markdown string ready for download.
        """
        sections: list[str] = [
            self._header(filename, components),
            self._overview_section(ai_result.overall_summary),
            self._metadata_section(components),
            self._components_table(components),
            self._component_summaries_section(ai_result.component_summaries),
            self._architecture_section(ai_result.architecture_description),
            self._full_documentation_section(ai_result.raw_documentation),
            self._footer(),
        ]
        return "\n\n".join(s for s in sections if s.strip())

    # ------------------------------------------------------------------
    # Private section builders
    # ------------------------------------------------------------------

    @staticmethod
    def _header(filename: str, components: CodeComponents) -> str:
        generated_at = datetime.now().strftime("%Y-%m-%d %H:%M")
        return (
            f"# Code Documentation: `{filename}`\n\n"
            f"> **Language:** {components.language.capitalize()}  \n"
            f"> **Generated:** {generated_at}"
        )

    @staticmethod
    def _overview_section(summary: str) -> str:
        body = summary.strip() if summary.strip() else "_No summary generated._"
        return f"## Overview\n\n{body}"

    @staticmethod
    def _metadata_section(components: CodeComponents) -> str:
        return (
            "## File Metadata\n\n"
            f"| Property | Value |\n"
            f"|---|---|\n"
            f"| Language | {components.language.capitalize()} |\n"
            f"| Lines of Code | {components.line_count} |\n"
            f"| Functions Found | {len(components.functions)} |\n"
            f"| Classes Found | {len(components.classes)} |\n"
            f"| Imports Found | {len(components.imports)} |"
        )

    @staticmethod
    def _components_table(components: CodeComponents) -> str:
        lines: list[str] = ["## Detected Components\n"]

        # Imports
        lines.append("### Imports / Dependencies")
        if components.imports:
            lines.extend(f"- `{imp}`" for imp in components.imports)
        else:
            lines.append("_None detected_")

        # Functions
        lines.append("\n### Functions / Methods")
        if components.functions:
            lines.extend(f"- `{fn}`" for fn in components.functions)
        else:
            lines.append("_None detected_")

        # Classes
        lines.append("\n### Classes")
        if components.classes:
            lines.extend(f"- `{cls}`" for cls in components.classes)
        else:
            lines.append("_None detected_")

        return "\n".join(lines)

    @staticmethod
    def _component_summaries_section(summaries: dict[str, str]) -> str:
        if not summaries:
            return (
                "## Component Explanations\n\n"
                "_No per-component summaries were generated._"
            )
        lines = ["## Component Explanations\n"]
        for name, description in summaries.items():
            lines.append(f"### `{name}`\n\n{description}\n")
        return "\n".join(lines)

    @staticmethod
    def _architecture_section(description: str) -> str:
        if not description.strip():
            return (
                "## Architecture / System Diagram\n\n"
                "_No architecture description was generated._"
            )
        return f"## Architecture / System Diagram\n\n{description.strip()}"

    @staticmethod
    def _full_documentation_section(raw_docs: str) -> str:
        if not raw_docs.strip():
            return (
                "## Full AI-Generated Documentation\n\n"
                "_No detailed documentation was generated._"
            )
        return f"## Full AI-Generated Documentation\n\n{raw_docs.strip()}"

    @staticmethod
    def _footer() -> str:
        return (
            "---\n\n"
            "_Documentation generated by the AI-Driven Code Intelligence System._"
        )
