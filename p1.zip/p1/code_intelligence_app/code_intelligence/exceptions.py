"""
Custom exception hierarchy for the Code Intelligence application.

All application exceptions inherit from CodeIntelligenceError so callers
can catch the base class when they want to handle any application error
uniformly, or catch a specific subclass for granular handling.
"""


class CodeIntelligenceError(Exception):
    """Base class for all application-specific exceptions.

    Every subclass stores a human-readable ``message`` attribute so the
    Streamlit UI can display ``e.message`` directly without further
    formatting.
    """

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.message: str = message


# ---------------------------------------------------------------------------
# File-validation exceptions
# ---------------------------------------------------------------------------


class InvalidFileTypeError(CodeIntelligenceError):
    """Raised when the uploaded file has an unsupported extension."""


class FileTooLargeError(CodeIntelligenceError):
    """Raised when the uploaded file exceeds the maximum allowed size."""


class EmptyFileError(CodeIntelligenceError):
    """Raised when the uploaded file contains no usable text content."""


# ---------------------------------------------------------------------------
# AI-layer exceptions
# ---------------------------------------------------------------------------


class AIServiceError(CodeIntelligenceError):
    """Raised when the Watsonx SDK call fails (network, auth, timeout, etc.)."""


class AIResponseParseError(CodeIntelligenceError):
    """Raised when the AI response cannot be parsed into the expected structure."""


# ---------------------------------------------------------------------------
# Static-analysis exceptions
# ---------------------------------------------------------------------------


class UnsupportedLanguageError(CodeIntelligenceError):
    """Raised when the code language is not supported by the static analyser."""
