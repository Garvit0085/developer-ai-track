"""
FileHandler — validates and reads uploaded source-code files.

This module is deliberately decoupled from Streamlit: it receives plain
``bytes`` and a filename string so it can be unit-tested without any
Streamlit context.
"""
from __future__ import annotations

import os

from code_intelligence.config import EXTENSION_TO_LANGUAGE, Settings
from code_intelligence.exceptions import (
    EmptyFileError,
    FileTooLargeError,
    InvalidFileTypeError,
)
from code_intelligence.models import UploadedFile


class FileHandler:
    """Validates and reads uploaded source-code files.

    Args:
        settings: Application settings (allowed extensions, max file size).
                  Defaults to a freshly constructed ``Settings()`` instance.
    """

    def __init__(self, settings: Settings | None = None) -> None:
        self._settings: Settings = settings or Settings()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def validate_file(self, filename: str, content_bytes: bytes) -> None:
        """Validate a file before processing.

        Checks are executed in order of cheapness:
        1. Extension is in the allowed list.
        2. File size does not exceed the configured maximum.
        3. File is not empty / blank.
        4. Content can be decoded as UTF-8 text.

        Args:
            filename:      Original name of the file (used to extract the extension).
            content_bytes: Raw bytes read from the uploaded file.

        Raises:
            InvalidFileTypeError: Extension is not supported.
            FileTooLargeError:    File exceeds ``max_file_size_bytes``.
            EmptyFileError:       File contains no usable text content.
        """
        extension = os.path.splitext(filename)[1].lower()
        if extension not in self._settings.allowed_extensions:
            raise InvalidFileTypeError(
                f"Unsupported file type '{extension}'. "
                f"Allowed types: {', '.join(sorted(self._settings.allowed_extensions))}"
            )

        if len(content_bytes) > self._settings.max_file_size_bytes:
            size_kb = len(content_bytes) / 1024
            limit_kb = self._settings.max_file_size_bytes / 1024
            raise FileTooLargeError(
                f"File is {size_kb:.1f} KB — maximum allowed size is {limit_kb:.0f} KB."
            )

        # Attempt UTF-8 decode to verify the file is readable text.
        try:
            text = content_bytes.decode("utf-8")
        except UnicodeDecodeError:
            raise EmptyFileError(
                "The file does not appear to contain valid UTF-8 text. "
                "Please upload a plain-text source-code file."
            )

        if not text.strip():
            raise EmptyFileError(
                "The uploaded file is empty or contains only whitespace."
            )

    def read_file_content(
        self, filename: str, content_bytes: bytes
    ) -> UploadedFile:
        """Validate and decode an uploaded file into an ``UploadedFile``.

        Args:
            filename:      Original name of the file.
            content_bytes: Raw bytes read from the uploaded file.

        Returns:
            A populated :class:`~code_intelligence.models.UploadedFile`.

        Raises:
            InvalidFileTypeError: Extension is not supported.
            FileTooLargeError:    File exceeds the size limit.
            EmptyFileError:       File contains no usable text content.
        """
        self.validate_file(filename, content_bytes)

        extension = os.path.splitext(filename)[1].lower()
        # Decode with ``errors='replace'`` as a safety net (validation above
        # already ensures valid UTF-8, but this avoids any edge-case crash).
        raw_content = content_bytes.decode("utf-8", errors="replace")

        return UploadedFile(
            filename=filename,
            extension=extension,
            raw_content=raw_content,
            size_bytes=len(content_bytes),
        )

    @staticmethod
    def extension_to_language(extension: str) -> str:
        """Return the display language name for a given file extension.

        Args:
            extension: Lower-cased extension including the dot (e.g. ``.py``).

        Returns:
            Language string understood by ``st.code()`` (e.g. ``"python"``).
        """
        return EXTENSION_TO_LANGUAGE.get(extension, "text")
