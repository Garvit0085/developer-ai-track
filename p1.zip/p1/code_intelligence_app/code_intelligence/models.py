"""
Data models (plain dataclasses) used as typed transfer objects between layers.

None of these classes contain business logic — they are simple containers
that make the data contract between modules explicit and type-safe.
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class UploadedFile:
    """Represents a successfully validated and decoded source-code file.

    Attributes:
        filename:    Original name of the uploaded file (e.g. ``main.py``).
        extension:   Lower-cased file extension including the dot (e.g. ``.py``).
        raw_content: Full source code decoded as a UTF-8 string.
        size_bytes:  Size of the raw file in bytes.
    """

    filename: str
    extension: str
    raw_content: str
    size_bytes: int


@dataclass
class CodeComponents:
    """Holds the results of static code-structure analysis.

    Attributes:
        language:  Human-readable language name (e.g. ``"python"``).
        imports:   List of import/include statement strings found in the code.
        functions: List of function/method names found in the code.
        classes:   List of class names found in the code.
        line_count: Total number of lines in the source file.
    """

    language: str
    imports: list[str] = field(default_factory=list)
    functions: list[str] = field(default_factory=list)
    classes: list[str] = field(default_factory=list)
    line_count: int = 0


@dataclass
class AIAnalysisResult:
    """Holds the structured output returned by the AI service.

    Attributes:
        overall_summary:       Plain-English explanation of what the code does.
        component_summaries:   Maps each function/class name to a one-sentence
                               description of its purpose.
        architecture_description: Textual description of the system architecture
                                  or data-flow, potentially in Mermaid format.
        raw_documentation:     The full markdown documentation block generated
                               by the AI model.
    """

    overall_summary: str = ""
    component_summaries: dict[str, str] = field(default_factory=dict)
    architecture_description: str = ""
    raw_documentation: str = ""
