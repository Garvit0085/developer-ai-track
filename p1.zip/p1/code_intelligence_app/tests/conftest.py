"""
Shared pytest fixtures available to all test modules.
"""
from __future__ import annotations

import pytest

from code_intelligence.config import Settings
from code_intelligence.models import AIAnalysisResult, CodeComponents, UploadedFile


@pytest.fixture()
def default_settings() -> Settings:
    """A Settings instance with no real API credentials (safe for unit tests)."""
    return Settings()


@pytest.fixture()
def sample_python_code() -> str:
    return (
        "import os\n"
        "import sys\n"
        "\n"
        "class Greeter:\n"
        "    def greet(self, name: str) -> str:\n"
        '        return f"Hello, {name}!"\n'
        "\n"
        "def main() -> None:\n"
        '    g = Greeter()\n'
        '    print(g.greet("world"))\n'
        "\n"
        "if __name__ == '__main__':\n"
        "    main()\n"
    )


@pytest.fixture()
def sample_js_code() -> str:
    return (
        "const express = require('express');\n"
        "import { foo } from './foo.js';\n"
        "\n"
        "class Server {\n"
        "    constructor() {}\n"
        "}\n"
        "\n"
        "function startServer() {\n"
        "    const app = express();\n"
        "    return app;\n"
        "}\n"
    )


@pytest.fixture()
def uploaded_python_file(sample_python_code: str) -> UploadedFile:
    return UploadedFile(
        filename="example.py",
        extension=".py",
        raw_content=sample_python_code,
        size_bytes=len(sample_python_code.encode()),
    )


@pytest.fixture()
def sample_components() -> CodeComponents:
    return CodeComponents(
        language="python",
        imports=["os", "sys"],
        functions=["main"],
        classes=["Greeter"],
        line_count=13,
    )


@pytest.fixture()
def sample_ai_result() -> AIAnalysisResult:
    return AIAnalysisResult(
        overall_summary="This script greets the user.",
        component_summaries={
            "Greeter": "A class that generates greeting messages.",
            "main": "The entry point of the script.",
        },
        architecture_description="Single-module script with a simple class.",
        raw_documentation="## Overview\nThis is a greeter script.",
    )
