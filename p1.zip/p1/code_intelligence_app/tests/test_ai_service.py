"""Tests for AIService — mocked Watsonx calls."""
from __future__ import annotations

import pytest

from code_intelligence.ai_service import (
    AIService,
    _SECTION_ARCHITECTURE,
    _SECTION_COMPONENTS,
    _SECTION_DELIMITER,
    _SECTION_DOCUMENTATION,
    _SECTION_OVERALL,
)
from code_intelligence.config import Settings
from code_intelligence.exceptions import AIResponseParseError, AIServiceError
from code_intelligence.models import AIAnalysisResult, CodeComponents, UploadedFile


def _make_settings(with_credentials: bool = True) -> Settings:
    """Return a Settings instance with or without fake credentials."""
    import os
    if with_credentials:
        os.environ["WATSONX_API_KEY"] = "test-key"
        os.environ["WATSONX_PROJECT_ID"] = "test-project"
    else:
        os.environ.pop("WATSONX_API_KEY", None)
        os.environ.pop("WATSONX_PROJECT_ID", None)
    return Settings()


def _well_formed_response(
    overall: str = "It greets the user.",
    components: str = "main: Entry point of the script.",
    architecture: str = "Linear single-file script.",
    docs: str = "## Overview\nA greeting script.",
) -> str:
    return (
        f"{_SECTION_DELIMITER}\n{_SECTION_OVERALL}\n{overall}\n"
        f"{_SECTION_DELIMITER}\n{_SECTION_COMPONENTS}\n{components}\n"
        f"{_SECTION_DELIMITER}\n{_SECTION_ARCHITECTURE}\n{architecture}\n"
        f"{_SECTION_DELIMITER}\n{_SECTION_DOCUMENTATION}\n{docs}\n"
    )


@pytest.fixture()
def uploaded_file() -> UploadedFile:
    return UploadedFile(
        filename="hello.py",
        extension=".py",
        raw_content="def main(): print('hi')\n",
        size_bytes=24,
    )


@pytest.fixture()
def components() -> CodeComponents:
    return CodeComponents(
        language="python",
        imports=[],
        functions=["main"],
        classes=[],
        line_count=1,
    )


# ---------------------------------------------------------------------------
# _parse_response
# ---------------------------------------------------------------------------

class TestParseResponse:
    """Unit tests for the private parser — called directly via the service."""

    def _service(self) -> AIService:
        """Create an AIService without initialising the real SDK client."""
        svc = object.__new__(AIService)
        svc._settings = Settings()
        svc._model = None
        return svc  # type: ignore[return-value]

    def test_parses_well_formed_response(self) -> None:
        svc = self._service()
        raw = _well_formed_response()
        result = svc._parse_response(raw)
        assert isinstance(result, AIAnalysisResult)
        assert "greets" in result.overall_summary

    def test_parses_component_summaries(self) -> None:
        svc = self._service()
        raw = _well_formed_response(components="add: Adds two numbers.\nsubtract: Subtracts.")
        result = svc._parse_response(raw)
        assert "add" in result.component_summaries
        assert "subtract" in result.component_summaries

    def test_parses_architecture(self) -> None:
        svc = self._service()
        raw = _well_formed_response(architecture="A three-layer architecture.")
        result = svc._parse_response(raw)
        assert "three-layer" in result.architecture_description

    def test_parses_documentation(self) -> None:
        svc = self._service()
        raw = _well_formed_response(docs="## Overview\nHello world script.")
        result = svc._parse_response(raw)
        assert "Overview" in result.raw_documentation

    def test_empty_response_raises(self) -> None:
        svc = self._service()
        with pytest.raises(AIResponseParseError):
            svc._parse_response("")

    def test_whitespace_only_raises(self) -> None:
        svc = self._service()
        with pytest.raises(AIResponseParseError):
            svc._parse_response("   \n  ")

    def test_malformed_response_falls_back_to_summary(self) -> None:
        svc = self._service()
        raw = "The code is a simple script that prints hello."
        result = svc._parse_response(raw)
        assert result.overall_summary == raw
        assert result.component_summaries == {}
        assert result.architecture_description == ""


# ---------------------------------------------------------------------------
# _build_prompt
# ---------------------------------------------------------------------------

class TestBuildPrompt:
    def test_prompt_contains_filename(
        self, uploaded_file: UploadedFile, components: CodeComponents
    ) -> None:
        svc = object.__new__(AIService)
        svc._settings = Settings()
        svc._model = None
        prompt = svc._build_prompt(uploaded_file, components)
        assert "hello.py" in prompt

    def test_prompt_contains_section_headers(
        self, uploaded_file: UploadedFile, components: CodeComponents
    ) -> None:
        svc = object.__new__(AIService)
        svc._settings = Settings()
        svc._model = None
        prompt = svc._build_prompt(uploaded_file, components)
        assert _SECTION_OVERALL in prompt
        assert _SECTION_COMPONENTS in prompt
        assert _SECTION_ARCHITECTURE in prompt
        assert _SECTION_DOCUMENTATION in prompt

    def test_prompt_contains_source_code(
        self, uploaded_file: UploadedFile, components: CodeComponents
    ) -> None:
        svc = object.__new__(AIService)
        svc._settings = Settings()
        svc._model = None
        prompt = svc._build_prompt(uploaded_file, components)
        assert "def main" in prompt

    def test_long_code_is_truncated(self, components: CodeComponents) -> None:
        svc = object.__new__(AIService)
        svc._settings = Settings()
        svc._model = None
        long_code = "x = 1\n" * 2000  # well over 6 000 chars
        big_file = UploadedFile("big.py", ".py", long_code, len(long_code))
        prompt = svc._build_prompt(big_file, components)
        assert "truncated" in prompt


# ---------------------------------------------------------------------------
# analyze_code with mocked SDK
# ---------------------------------------------------------------------------

class TestAnalyzeCode:
    def test_successful_analysis(
        self,
        mocker,  # pytest-mock
        uploaded_file: UploadedFile,
        components: CodeComponents,
    ) -> None:
        svc = object.__new__(AIService)
        svc._settings = Settings()
        # Patch _call_model so no real API call is made.
        mocker.patch.object(
            svc, "_call_model", return_value=_well_formed_response()
        )
        result = svc.analyze_code(uploaded_file, components)
        assert isinstance(result, AIAnalysisResult)
        assert result.overall_summary != ""

    def test_sdk_exception_raises_ai_service_error(
        self,
        mocker,
        uploaded_file: UploadedFile,
        components: CodeComponents,
    ) -> None:
        svc = object.__new__(AIService)
        svc._settings = Settings()
        mocker.patch.object(
            svc, "_call_model", side_effect=AIServiceError("timeout")
        )
        with pytest.raises(AIServiceError):
            svc.analyze_code(uploaded_file, components)

    def test_missing_credentials_raises_on_call(
        self,
        uploaded_file: UploadedFile,
        components: CodeComponents,
    ) -> None:
        import os
        os.environ.pop("WATSONX_API_KEY", None)
        os.environ.pop("WATSONX_PROJECT_ID", None)
        svc = AIService(Settings())  # model will be None
        with pytest.raises(AIServiceError) as exc_info:
            svc.analyze_code(uploaded_file, components)
        assert "credentials" in exc_info.value.message.lower()
