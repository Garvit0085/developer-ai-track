"""Tests for CodeAnalyzer — static code structure extraction."""
from __future__ import annotations

import pytest

from code_intelligence.code_analyzer import CodeAnalyzer
from code_intelligence.exceptions import UnsupportedLanguageError
from code_intelligence.models import CodeComponents


@pytest.fixture()
def analyzer() -> CodeAnalyzer:
    return CodeAnalyzer()


# ---------------------------------------------------------------------------
# Python extraction (ast-based)
# ---------------------------------------------------------------------------

class TestPythonExtraction:
    def test_detects_functions(self, analyzer: CodeAnalyzer) -> None:
        code = "def foo(): pass\ndef bar(): pass\n"
        result = analyzer.extract_components(code, "python")
        assert "foo" in result.functions
        assert "bar" in result.functions

    def test_detects_classes(self, analyzer: CodeAnalyzer) -> None:
        code = "class MyClass:\n    pass\n"
        result = analyzer.extract_components(code, "python")
        assert "MyClass" in result.classes

    def test_detects_simple_import(self, analyzer: CodeAnalyzer) -> None:
        code = "import os\nimport sys\n"
        result = analyzer.extract_components(code, "python")
        assert any("os" in imp for imp in result.imports)
        assert any("sys" in imp for imp in result.imports)

    def test_detects_from_import(self, analyzer: CodeAnalyzer) -> None:
        code = "from pathlib import Path\n"
        result = analyzer.extract_components(code, "python")
        assert any("pathlib" in imp for imp in result.imports)

    def test_detects_async_function(self, analyzer: CodeAnalyzer) -> None:
        code = "async def fetch(): pass\n"
        result = analyzer.extract_components(code, "python")
        assert "fetch" in result.functions

    def test_line_count(self, analyzer: CodeAnalyzer) -> None:
        code = "a = 1\nb = 2\nc = 3\n"
        result = analyzer.extract_components(code, "python")
        assert result.line_count == 3

    def test_returns_code_components(self, analyzer: CodeAnalyzer) -> None:
        result = analyzer.extract_components("x = 1\n", "python")
        assert isinstance(result, CodeComponents)

    def test_language_set(self, analyzer: CodeAnalyzer) -> None:
        result = analyzer.extract_components("x = 1\n", "python")
        assert result.language == "python"

    def test_syntax_error_falls_back_gracefully(
        self, analyzer: CodeAnalyzer
    ) -> None:
        # Should not raise — falls back to regex.
        result = analyzer.extract_components("def (broken syntax:", "python")
        assert isinstance(result, CodeComponents)

    def test_full_sample(
        self, analyzer: CodeAnalyzer, sample_python_code: str
    ) -> None:
        result = analyzer.extract_components(sample_python_code, "python")
        assert "Greeter" in result.classes
        assert "main" in result.functions
        assert any("os" in imp for imp in result.imports)
        assert result.line_count > 0


# ---------------------------------------------------------------------------
# JavaScript extraction (regex-based)
# ---------------------------------------------------------------------------

class TestJavaScriptExtraction:
    def test_detects_function_declaration(self, analyzer: CodeAnalyzer) -> None:
        code = "function greet(name) { return name; }\n"
        result = analyzer.extract_components(code, "javascript")
        assert "greet" in result.functions

    def test_detects_class(self, analyzer: CodeAnalyzer) -> None:
        code = "class Animal {\n    constructor() {}\n}\n"
        result = analyzer.extract_components(code, "javascript")
        assert "Animal" in result.classes

    def test_detects_require_import(self, analyzer: CodeAnalyzer) -> None:
        code = "const express = require('express');\n"
        result = analyzer.extract_components(code, "javascript")
        assert any("express" in imp for imp in result.imports)

    def test_language_set(self, analyzer: CodeAnalyzer) -> None:
        result = analyzer.extract_components("var x = 1;", "javascript")
        assert result.language == "javascript"


# ---------------------------------------------------------------------------
# Java extraction
# ---------------------------------------------------------------------------

class TestJavaExtraction:
    def test_detects_class(self, analyzer: CodeAnalyzer) -> None:
        code = "public class Main {\n    public static void main(String[] args) {}\n}\n"
        result = analyzer.extract_components(code, "java")
        assert "Main" in result.classes

    def test_detects_method(self, analyzer: CodeAnalyzer) -> None:
        code = "public class A {\n    public void doSomething() {}\n}\n"
        result = analyzer.extract_components(code, "java")
        assert "doSomething" in result.functions

    def test_detects_import(self, analyzer: CodeAnalyzer) -> None:
        code = "import java.util.List;\nimport java.io.File;\n"
        result = analyzer.extract_components(code, "java")
        assert any("java.util.List" in imp for imp in result.imports)


# ---------------------------------------------------------------------------
# C/C++ extraction
# ---------------------------------------------------------------------------

class TestCppExtraction:
    def test_detects_struct(self, analyzer: CodeAnalyzer) -> None:
        code = "struct Node {\n    int value;\n};\n"
        result = analyzer.extract_components(code, "cpp")
        assert "Node" in result.classes

    def test_detects_include(self, analyzer: CodeAnalyzer) -> None:
        code = "#include <iostream>\n"
        result = analyzer.extract_components(code, "cpp")
        assert any("iostream" in imp for imp in result.imports)


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------

class TestEdgeCases:
    def test_empty_code_returns_zeroed_components(
        self, analyzer: CodeAnalyzer
    ) -> None:
        result = analyzer.extract_components("", "python")
        assert result.functions == []
        assert result.classes == []
        assert result.imports == []
        assert result.line_count == 0

    def test_unsupported_language_raises(self, analyzer: CodeAnalyzer) -> None:
        with pytest.raises(UnsupportedLanguageError) as exc_info:
            analyzer.extract_components("code", "ruby")
        assert "ruby" in exc_info.value.message.lower()

    def test_truncation_at_20_items(self, analyzer: CodeAnalyzer) -> None:
        # Generate 25 functions to verify truncation to 20.
        lines = [f"def func_{i}(): pass" for i in range(25)]
        code = "\n".join(lines)
        result = analyzer.extract_components(code, "python")
        assert len(result.functions) <= 20

    def test_whitespace_only_code(self, analyzer: CodeAnalyzer) -> None:
        result = analyzer.extract_components("   \n\n  ", "python")
        assert result.line_count == 0

    def test_case_insensitive_language(self, analyzer: CodeAnalyzer) -> None:
        result = analyzer.extract_components("x = 1", "Python")
        assert result.language == "python"
