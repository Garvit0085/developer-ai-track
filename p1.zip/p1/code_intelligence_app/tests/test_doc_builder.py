"""Tests for DocBuilder — Markdown documentation assembly."""
from __future__ import annotations

import pytest

from code_intelligence.doc_builder import DocBuilder
from code_intelligence.models import AIAnalysisResult, CodeComponents


@pytest.fixture()
def builder() -> DocBuilder:
    return DocBuilder()


@pytest.fixture()
def full_components() -> CodeComponents:
    return CodeComponents(
        language="python",
        imports=["os", "sys"],
        functions=["main", "helper"],
        classes=["Greeter"],
        line_count=20,
    )


@pytest.fixture()
def full_ai_result() -> AIAnalysisResult:
    return AIAnalysisResult(
        overall_summary="This script greets the user.",
        component_summaries={
            "Greeter": "A class that produces greeting messages.",
            "main": "The entry point of the script.",
        },
        architecture_description="A single-module script with one class.",
        raw_documentation="## Overview\nA simple greeting program.",
    )


class TestBuildDocumentation:
    def test_returns_string(
        self,
        builder: DocBuilder,
        full_components: CodeComponents,
        full_ai_result: AIAnalysisResult,
    ) -> None:
        result = builder.build_documentation(full_components, full_ai_result, "hello.py")
        assert isinstance(result, str)

    def test_contains_filename(
        self,
        builder: DocBuilder,
        full_components: CodeComponents,
        full_ai_result: AIAnalysisResult,
    ) -> None:
        result = builder.build_documentation(full_components, full_ai_result, "hello.py")
        assert "hello.py" in result

    def test_contains_overview_section(
        self,
        builder: DocBuilder,
        full_components: CodeComponents,
        full_ai_result: AIAnalysisResult,
    ) -> None:
        result = builder.build_documentation(full_components, full_ai_result, "hello.py")
        assert "## Overview" in result

    def test_contains_overall_summary(
        self,
        builder: DocBuilder,
        full_components: CodeComponents,
        full_ai_result: AIAnalysisResult,
    ) -> None:
        result = builder.build_documentation(full_components, full_ai_result, "hello.py")
        assert "greets the user" in result

    def test_contains_function_names(
        self,
        builder: DocBuilder,
        full_components: CodeComponents,
        full_ai_result: AIAnalysisResult,
    ) -> None:
        result = builder.build_documentation(full_components, full_ai_result, "hello.py")
        assert "main" in result
        assert "helper" in result

    def test_contains_class_names(
        self,
        builder: DocBuilder,
        full_components: CodeComponents,
        full_ai_result: AIAnalysisResult,
    ) -> None:
        result = builder.build_documentation(full_components, full_ai_result, "hello.py")
        assert "Greeter" in result

    def test_contains_imports(
        self,
        builder: DocBuilder,
        full_components: CodeComponents,
        full_ai_result: AIAnalysisResult,
    ) -> None:
        result = builder.build_documentation(full_components, full_ai_result, "hello.py")
        assert "os" in result
        assert "sys" in result

    def test_contains_metadata_section(
        self,
        builder: DocBuilder,
        full_components: CodeComponents,
        full_ai_result: AIAnalysisResult,
    ) -> None:
        result = builder.build_documentation(full_components, full_ai_result, "hello.py")
        assert "File Metadata" in result
        assert "20" in result  # line count

    def test_contains_architecture_section(
        self,
        builder: DocBuilder,
        full_components: CodeComponents,
        full_ai_result: AIAnalysisResult,
    ) -> None:
        result = builder.build_documentation(full_components, full_ai_result, "hello.py")
        assert "Architecture" in result
        assert "single-module" in result

    def test_contains_full_documentation_section(
        self,
        builder: DocBuilder,
        full_components: CodeComponents,
        full_ai_result: AIAnalysisResult,
    ) -> None:
        result = builder.build_documentation(full_components, full_ai_result, "hello.py")
        assert "Full AI-Generated Documentation" in result

    def test_contains_component_summaries(
        self,
        builder: DocBuilder,
        full_components: CodeComponents,
        full_ai_result: AIAnalysisResult,
    ) -> None:
        result = builder.build_documentation(full_components, full_ai_result, "hello.py")
        assert "Component Explanations" in result
        assert "greeting messages" in result

    def test_contains_footer(
        self,
        builder: DocBuilder,
        full_components: CodeComponents,
        full_ai_result: AIAnalysisResult,
    ) -> None:
        result = builder.build_documentation(full_components, full_ai_result, "hello.py")
        assert "Code Intelligence" in result

    def test_empty_lists_show_none_detected(
        self,
        builder: DocBuilder,
        full_ai_result: AIAnalysisResult,
    ) -> None:
        empty_components = CodeComponents(language="python", line_count=5)
        result = builder.build_documentation(
            empty_components, full_ai_result, "empty.py"
        )
        assert "_None detected_" in result

    def test_empty_ai_result_handled_gracefully(
        self,
        builder: DocBuilder,
        full_components: CodeComponents,
    ) -> None:
        empty_ai = AIAnalysisResult()
        result = builder.build_documentation(full_components, empty_ai, "file.py")
        assert "file.py" in result
        assert isinstance(result, str)
