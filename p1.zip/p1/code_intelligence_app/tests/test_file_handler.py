"""Tests for FileHandler — validation and file reading."""
from __future__ import annotations

import pytest

from code_intelligence.config import Settings
from code_intelligence.exceptions import (
    EmptyFileError,
    FileTooLargeError,
    InvalidFileTypeError,
)
from code_intelligence.file_handler import FileHandler
from code_intelligence.models import UploadedFile


@pytest.fixture()
def handler() -> FileHandler:
    return FileHandler(Settings())


class TestValidateFile:
    """validate_file raises the correct exception for each invalid input."""

    def test_valid_python_file_passes(self, handler: FileHandler) -> None:
        handler.validate_file("main.py", b"print('hello')")

    def test_valid_js_file_passes(self, handler: FileHandler) -> None:
        handler.validate_file("app.js", b"console.log('hi');")

    def test_valid_java_file_passes(self, handler: FileHandler) -> None:
        handler.validate_file("Main.java", b"public class Main {}")

    def test_valid_cpp_file_passes(self, handler: FileHandler) -> None:
        handler.validate_file("main.cpp", b"int main() { return 0; }")

    def test_valid_c_file_passes(self, handler: FileHandler) -> None:
        handler.validate_file("main.c", b"int main() { return 0; }")

    def test_unsupported_extension_raises(self, handler: FileHandler) -> None:
        with pytest.raises(InvalidFileTypeError) as exc_info:
            handler.validate_file("document.pdf", b"some content")
        assert ".pdf" in exc_info.value.message

    def test_txt_extension_raises(self, handler: FileHandler) -> None:
        with pytest.raises(InvalidFileTypeError):
            handler.validate_file("readme.txt", b"hello")

    def test_no_extension_raises(self, handler: FileHandler) -> None:
        with pytest.raises(InvalidFileTypeError):
            handler.validate_file("Makefile", b"all: build")

    def test_file_too_large_raises(self, handler: FileHandler) -> None:
        big_content = b"x" * (51_201)  # 1 byte over 50 KB
        with pytest.raises(FileTooLargeError) as exc_info:
            handler.validate_file("big.py", big_content)
        assert "KB" in exc_info.value.message

    def test_file_exactly_at_limit_passes(self, handler: FileHandler) -> None:
        content = b"# " + b"x" * (51_198)  # exactly 51 200 bytes
        handler.validate_file("edge.py", content)

    def test_empty_file_raises(self, handler: FileHandler) -> None:
        with pytest.raises(EmptyFileError) as exc_info:
            handler.validate_file("empty.py", b"")
        assert "empty" in exc_info.value.message.lower()

    def test_whitespace_only_raises(self, handler: FileHandler) -> None:
        with pytest.raises(EmptyFileError):
            handler.validate_file("blank.py", b"   \n\n   ")

    def test_binary_content_raises(self, handler: FileHandler) -> None:
        with pytest.raises(EmptyFileError):
            handler.validate_file("bad.py", bytes(range(256)))


class TestReadFileContent:
    """read_file_content returns a correct UploadedFile on success."""

    def test_returns_uploaded_file(self, handler: FileHandler) -> None:
        result = handler.read_file_content("script.py", b"x = 1\n")
        assert isinstance(result, UploadedFile)

    def test_filename_preserved(self, handler: FileHandler) -> None:
        result = handler.read_file_content("my_module.py", b"pass\n")
        assert result.filename == "my_module.py"

    def test_extension_lower_cased(self, handler: FileHandler) -> None:
        result = handler.read_file_content("Main.PY", b"pass\n")
        assert result.extension == ".py"

    def test_raw_content_decoded(self, handler: FileHandler) -> None:
        code = "print('héllo')\n"
        result = handler.read_file_content("f.py", code.encode("utf-8"))
        assert result.raw_content == code

    def test_size_bytes_correct(self, handler: FileHandler) -> None:
        content = b"x = 42\n"
        result = handler.read_file_content("f.py", content)
        assert result.size_bytes == len(content)

    def test_invalid_file_raises_before_returning(
        self, handler: FileHandler
    ) -> None:
        with pytest.raises(InvalidFileTypeError):
            handler.read_file_content("image.png", b"\x89PNG")


class TestExtensionToLanguage:
    """Static helper maps extensions to language names."""

    def test_py(self) -> None:
        assert FileHandler.extension_to_language(".py") == "python"

    def test_js(self) -> None:
        assert FileHandler.extension_to_language(".js") == "javascript"

    def test_java(self) -> None:
        assert FileHandler.extension_to_language(".java") == "java"

    def test_cpp(self) -> None:
        assert FileHandler.extension_to_language(".cpp") == "cpp"

    def test_c(self) -> None:
        assert FileHandler.extension_to_language(".c") == "c"

    def test_unknown_returns_text(self) -> None:
        assert FileHandler.extension_to_language(".xyz") == "text"
