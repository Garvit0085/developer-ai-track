"""Integration smoke test — exercises the full pipeline without a real AI call."""
from __future__ import annotations

import pytest

from code_intelligence.code_analyzer import CodeAnalyzer
from code_intelligence.doc_builder import DocBuilder
from code_intelligence.file_handler import FileHandler
from code_intelligence.models import AIAnalysisResult

SAMPLE_PYTHON = b"""\
import os
import sys
from pathlib import Path


class DataProcessor:
    \"\"\"Processes input data files.\"\"\"

    def __init__(self, path: str) -> None:
        self.path = path

    def load(self) -> list[str]:
        \"\"\"Load and return lines from the file.\"\"\"
        with open(self.path) as f:
            return f.readlines()


def main() -> None:
    processor = DataProcessor("data.txt")
    lines = processor.load()
    print(f"Loaded {len(lines)} lines.")


if __name__ == "__main__":
    main()
"""


@pytest.fixture()
def pipeline():
    handler = FileHandler()
    analyzer = CodeAnalyzer()
    builder = DocBuilder()
    return handler, analyzer, builder


def test_full_pipeline_python(pipeline) -> None:
    """FileHandler → CodeAnalyzer → DocBuilder produces valid Markdown."""
    handler, analyzer, builder = pipeline

    # Step 1: parse the file
    code_file = handler.read_file_content("processor.py", SAMPLE_PYTHON)
    assert code_file.filename == "processor.py"
    assert code_file.extension == ".py"

    # Step 2: extract components
    components = analyzer.extract_components(code_file.raw_content, "python")
    assert "DataProcessor" in components.classes
    assert "main" in components.functions
    assert any("os" in imp for imp in components.imports)
    assert components.line_count > 0

    # Step 3: build documentation (AI result is mocked)
    fake_ai = AIAnalysisResult(
        overall_summary="This script loads and processes a data file.",
        component_summaries={
            "DataProcessor": "A class that reads lines from a file.",
            "main": "Entry point that creates a processor and prints line count.",
        },
        architecture_description="Single-module script with a processor class.",
        raw_documentation="## Overview\nProcesses text files line by line.",
    )
    doc = builder.build_documentation(components, fake_ai, code_file.filename)

    assert "processor.py" in doc
    assert "DataProcessor" in doc
    assert "main" in doc
    assert "## Overview" in doc
    assert "loads and processes" in doc
    assert "Architecture" in doc
    assert isinstance(doc, str)
    assert len(doc) > 100


def test_full_pipeline_javascript(pipeline) -> None:
    """Pipeline works end-to-end for a JavaScript file."""
    handler, analyzer, builder = pipeline

    js_code = (
        b"const http = require('http');\n\n"
        b"class Server {\n"
        b"    constructor(port) { this.port = port; }\n"
        b"}\n\n"
        b"function createServer(port) {\n"
        b"    return new Server(port);\n"
        b"}\n"
    )

    code_file = handler.read_file_content("server.js", js_code)
    components = analyzer.extract_components(code_file.raw_content, "javascript")

    assert "Server" in components.classes
    assert "createServer" in components.functions

    fake_ai = AIAnalysisResult(
        overall_summary="A simple HTTP server module.",
    )
    doc = builder.build_documentation(components, fake_ai, code_file.filename)
    assert "server.js" in doc
