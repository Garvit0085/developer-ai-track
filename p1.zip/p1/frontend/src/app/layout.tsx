import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Developer AI Track",
  description: "AI-powered developer productivity tool",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="min-h-screen bg-base-900 text-white">
        {children}
      </body>
    </html>
  );
}
