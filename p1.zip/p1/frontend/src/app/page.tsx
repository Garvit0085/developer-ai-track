import Link from "next/link";

export default function HomePage() {
  return (
    <main className="flex flex-col items-center justify-center min-h-screen px-6 text-center">
      {/* Badge */}
      <div className="mb-6 inline-flex items-center gap-2 px-3 py-1 rounded-full border border-accent-purple/40 bg-accent-purple/10 text-accent-purple font-mono text-xs">
        <span className="w-1.5 h-1.5 rounded-full bg-accent-purple animate-pulse-slow" />
        Watsonx AI · FastAPI · MongoDB
      </div>

      <h1 className="text-4xl sm:text-6xl font-mono font-semibold tracking-tight text-white mb-4">
        Developer{" "}
        <span className="text-transparent bg-clip-text bg-gradient-to-r from-accent-blue to-accent-purple">
          AI Track
        </span>
      </h1>

      <p className="max-w-xl text-muted font-mono text-sm sm:text-base mb-10 leading-relaxed">
        An AI-powered developer tool. Ask questions, generate code, and explore
        documentation — all streamed in real time.
      </p>

      <div className="flex gap-4">
        <Link href="/chat" className="btn-primary">
          Open Chat →
        </Link>
        <Link href="/docs" className="btn-ghost">
          API Docs
        </Link>
      </div>

      {/* Grid decoration */}
      <div className="pointer-events-none fixed inset-0 -z-10 opacity-[0.03]"
        style={{ backgroundImage: "linear-gradient(#8b949e 1px,transparent 1px),linear-gradient(90deg,#8b949e 1px,transparent 1px)", backgroundSize: "40px 40px" }} />
    </main>
  );
}
