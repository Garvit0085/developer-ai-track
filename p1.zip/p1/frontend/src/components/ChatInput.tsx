"use client";

import { useState, useRef, KeyboardEvent } from "react";

interface Props {
  onSend: (content: string) => void;
  disabled?: boolean;
}

export default function ChatInput({ onSend, disabled }: Props) {
  const [value, setValue] = useState("");
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const submit = () => {
    const trimmed = value.trim();
    if (!trimmed || disabled) return;
    onSend(trimmed);
    setValue("");
    if (textareaRef.current) textareaRef.current.style.height = "auto";
  };

  const onKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      submit();
    }
  };

  const autoResize = () => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 200)}px`;
  };

  return (
    <div className="glass flex items-end gap-3 p-3">
      <textarea
        ref={textareaRef}
        rows={1}
        className="flex-1 bg-transparent font-mono text-sm text-white placeholder:text-base-500
                   resize-none focus:outline-none leading-relaxed max-h-[200px] overflow-y-auto"
        placeholder="Ask anything… (Enter to send, Shift+Enter for newline)"
        value={value}
        disabled={disabled}
        onChange={(e) => { setValue(e.target.value); autoResize(); }}
        onKeyDown={onKeyDown}
      />

      <button
        onClick={submit}
        disabled={disabled || !value.trim()}
        className="btn-primary flex-shrink-0 h-9 w-9 flex items-center justify-center p-0"
        aria-label="Send message"
      >
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M14 2L2 8l5 2 2 5 5-13z" />
        </svg>
      </button>
    </div>
  );
}
