"use client";

import { motion } from "framer-motion";
import type { Message } from "@/types/chat";

interface Props {
  message: Message;
}

export default function ChatMessage({ message }: Props) {
  const isUser = message.role === "user";

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2 }}
      className={`flex gap-3 ${isUser ? "justify-end" : "justify-start"}`}
    >
      {/* Avatar */}
      {!isUser && (
        <div className="flex-shrink-0 w-7 h-7 rounded-md bg-accent-purple/20 border border-accent-purple/30
                        flex items-center justify-center font-mono text-xs text-accent-purple">
          AI
        </div>
      )}

      {/* Bubble */}
      <div
        className={`max-w-[75%] px-4 py-2.5 rounded-xl font-mono text-sm leading-relaxed whitespace-pre-wrap break-words
          ${isUser
            ? "bg-accent-blue/20 border border-accent-blue/30 text-white rounded-br-sm"
            : message.error
              ? "bg-accent-red/10 border border-accent-red/30 text-accent-red rounded-bl-sm"
              : "bg-base-800 border border-border text-white rounded-bl-sm"
          }`}
      >
        {message.content || (
          <span className="text-base-500 italic text-xs">thinking…</span>
        )}
      </div>

      {/* User avatar */}
      {isUser && (
        <div className="flex-shrink-0 w-7 h-7 rounded-md bg-accent-blue/20 border border-accent-blue/30
                        flex items-center justify-center font-mono text-xs text-accent-blue">
          U
        </div>
      )}
    </motion.div>
  );
}
