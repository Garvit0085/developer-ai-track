"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const navItems = [
  { href: "/",        label: "home",    icon: "⌂" },
  { href: "/chat",    label: "chat",    icon: "◈" },
  { href: "/docs",    label: "docs",    icon: "≡" },
];

export default function Sidebar() {
  const path = usePathname();

  return (
    <aside className="flex flex-col w-14 bg-base-800 border-r border-border py-4 items-center gap-2">
      {/* Logo mark */}
      <div className="w-8 h-8 rounded-md bg-gradient-to-br from-accent-blue to-accent-purple
                      flex items-center justify-center font-mono text-xs font-bold text-white mb-4">
        AI
      </div>

      {navItems.map(({ href, label, icon }) => (
        <Link
          key={href}
          href={href}
          title={label}
          className={`w-9 h-9 rounded-lg flex items-center justify-center font-mono text-base transition-colors duration-150
            ${path === href
              ? "bg-accent-blue/20 text-accent-blue border border-accent-blue/30"
              : "text-muted hover:text-white hover:bg-base-700"
            }`}
        >
          {icon}
        </Link>
      ))}

      {/* Bottom spacer */}
      <div className="flex-1" />
      <div className="w-7 h-7 rounded-full bg-base-600 border border-border flex items-center justify-center font-mono text-xs text-muted">
        U
      </div>
    </aside>
  );
}
