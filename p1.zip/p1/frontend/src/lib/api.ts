import type { Message } from "@/types/chat";

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

/**
 * Stream a chat completion from the FastAPI backend.
 * Calls `onChunk` for every streamed text delta.
 */
export async function streamChat(
  messages: Message[],
  onChunk: (chunk: string) => void
): Promise<void> {
  const response = await fetch(`${API_URL}/api/chat/stream`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      messages: messages.map(({ role, content }) => ({ role, content })),
    }),
  });

  if (!response.ok) {
    throw new Error(`API error: ${response.status} ${response.statusText}`);
  }

  const reader = response.body?.getReader();
  const decoder = new TextDecoder();

  if (!reader) throw new Error("No response body");

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    const text = decoder.decode(value, { stream: true });
    // Each line is "data: <chunk>\n\n" (SSE format)
    for (const line of text.split("\n")) {
      if (line.startsWith("data: ")) {
        const chunk = line.slice(6);
        if (chunk !== "[DONE]") onChunk(chunk);
      }
    }
  }
}

/** Fetch chat history from MongoDB via FastAPI. */
export async function fetchHistory(): Promise<Message[]> {
  const res = await fetch(`${API_URL}/api/history`);
  if (!res.ok) throw new Error("Failed to fetch history");
  return res.json();
}
