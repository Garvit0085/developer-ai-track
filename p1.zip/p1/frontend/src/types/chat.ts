export interface Message {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  timestamp: Date;
  error?: boolean;
}

export interface ChatRequest {
  messages: Omit<Message, "id" | "timestamp">[];
}
